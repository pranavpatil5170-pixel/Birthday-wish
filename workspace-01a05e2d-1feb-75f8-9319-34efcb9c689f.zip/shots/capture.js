const puppeteer = require("/home/user/node_modules/puppeteer");

(async () => {
  const browser = await puppeteer.launch({
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--force-color-profile=srgb"],
  });
  const sizes = [
    [390, 844, "mob"],
    [1280, 800, "desk"],
  ];
  const times = [900, 3200, 7000, 12000];

  for (const [w, h, tag] of sizes) {
    const page = await browser.newPage();
    await page.setViewport({ width: w, height: h, deviceScaleFactor: 1 });
    page.on("console", (m) => console.log(`[${tag}]`, m.type(), m.text()));
    page.on("pageerror", (e) => console.log(`[${tag}] PAGEERROR`, e.message));
    await page.goto("http://127.0.0.1:5173/?scene=1", { waitUntil: "networkidle0", timeout: 30000 });

    let prev = 0;
    for (const t of times) {
      await new Promise((r) => setTimeout(r, t - prev));
      prev = t;
      await page.screenshot({ path: `/home/user/shots/${tag}-${t}.png` });
    }
    await page.close();
  }
  await browser.close();
  console.log("done");
})().catch((e) => {
  console.error("CAPTURE FAILED:", e.message);
  process.exit(1);
});
