/**
 * ============================================================
 *  CENTRAL CONFIGURATION
 *  Everything personal lives here — edit this file only.
 *  No real information has been added yet; all placeholders.
 * ============================================================
 */

export const birthdayData = {
  // The birthday person
  name: "NAME",

  // The quote that appears inside the garden (Scene 3)
  quote: "YOUR QUOTE",

  // Optional attribution line under the quote, e.g. "— someone"
  quoteAttribution: "",

  // Your personal message (Scene 4 / Scene 8)
  message: "YOUR PERSONAL MESSAGE",

  // Who the experience is from
  sender: "YOUR NAME",

  // 2–4 personal photographs. Put files in /assets/photos/
  // and list them here. Order = display order.
  photos: [
    // { src: "assets/photos/01.jpg", caption: "" },
  ],

  // Optional background music (leave "" for silence)
  musicURL: "",

  // Opening line reserved for a later scene (not used in Scene 1)
  openingLine: "Something beautiful is going to bloom...",

  // Final line of the film (Scene 8)
  closingLine: "",
};

/* ------------------------------------------------------------
 *  EDITING GUIDE
 *  name        → used verbatim in the Scene 7 reveal
 *  quote       → split into lines automatically; use \n to force a break
 *  message     → plain text; \n creates line breaks
 *  photos      → keep them roughly the same aspect ratio for best results
 *  musicURL    → a local file ("assets/music.mp3") or an absolute URL
 * ------------------------------------------------------------ */
