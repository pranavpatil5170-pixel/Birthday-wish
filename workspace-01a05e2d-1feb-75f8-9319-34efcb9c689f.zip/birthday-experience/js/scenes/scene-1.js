/**
 * SCENE 1 — galaxy · meteor shower · blooming sunflowers · moon
 *
 * Timeline (seconds, approximate):
 *   0.0  true black — the film holds its breath
 *   1.3  sky fades in with the meteor shower (peaks ~2–4.8s, tapers to 8.2s)
 *   4.6  moon condenses out of the darkness, top-middle, smaller
 *   6.5  stems rise in a slow wave, left → right
 *   7.8  petals begin opening flower by flower, stem to bloom
 *  10.8  the compliment fades into the band between moon and garden
 *   ∞    ambient hold: twinkle, rare meteors, sway, moon breathing
 */

import { registerScene } from "../registry.js";

const R = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/* ---------------------------------------------------------------- *
 *  SKY — twinkling stars + meteor shower on a single canvas
 * ---------------------------------------------------------------- */

function createSky(canvas, reduced) {
  const ctx = canvas.getContext("2d");
  let w = 0, h = 0, stars = [], meteors = [];
  let raf = 0, t0 = 0, last = 0, acc = 0, nextAmbient = R(9, 13);

  function makeStars() {
    const n = Math.round((w * h) / 9000);
    const tints = ["255,255,255", "214,222,255", "233,225,255"];
    stars = Array.from({ length: n }, () => ({
      x: R(0, w), y: R(0, h),
      r: R(0.35, 1.25),
      p: R(0, Math.PI * 2),
      s: R(0.3, 1.3),
      a: R(0.22, 0.8),
      c: tints[(Math.random() * tints.length) | 0],
    }));
  }

  function resize() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    w = canvas.clientWidth; h = canvas.clientHeight;
    canvas.width = Math.max(1, Math.round(w * dpr));
    canvas.height = Math.max(1, Math.round(h * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    makeStars();
  }

  function spawnMeteor(dim) {
    const ang = R(0.62, 0.8) * Math.PI;          // radiant: upper right → lower left
    const sp = R(520, 980);
    meteors.push({
      x: R(-0.05, 1.08) * w,
      y: R(-0.12, 0.45) * h,
      vx: Math.cos(ang) * sp,
      vy: Math.sin(ang) * sp,
      len: sp * R(0.14, 0.2),
      age: 0,
      life: R(0.9, 1.5),
      dim: dim ? 0.4 : 0.9,
    });
  }

  function frame(now) {
    raf = requestAnimationFrame(frame);
    const t = (now - t0) / 1000;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    ctx.clearRect(0, 0, w, h);

    /* stars */
    for (const st of stars) {
      const tw = reduced ? 0.75 : 0.55 + 0.45 * Math.sin(t * st.s + st.p);
      ctx.globalAlpha = st.a * tw;
      ctx.fillStyle = `rgb(${st.c})`;
      ctx.beginPath();
      ctx.arc(st.x, st.y, st.r, 0, 6.2832);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    if (!reduced) {
      /* shower envelope: build, peak, taper, then rare ambient streaks */
      let rate = 0;
      if (t > 1.3 && t < 2) rate = 1.6;
      else if (t < 4.8) rate = 3.4;
      else if (t < 8.2) rate = 1.3;
      acc += rate * dt;
      while (acc >= 1) { acc -= 1; spawnMeteor(false); }
      if (t > nextAmbient) { spawnMeteor(true); nextAmbient = t + R(8, 15); }
    }

    /* meteors */
    ctx.lineCap = "round";
    meteors = meteors.filter((m) => m.age < m.life && m.x > -m.len && m.y < h + m.len);
    for (const m of meteors) {
      m.age += dt;
      m.x += m.vx * dt;
      m.y += m.vy * dt;
      const al = Math.sin(Math.PI * Math.min(1, m.age / m.life)) * m.dim;
      const d = Math.hypot(m.vx, m.vy) || 1;
      const nx = m.vx / d, ny = m.vy / d;
      const tx = m.x - nx * m.len, ty = m.y - ny * m.len;
      const g = ctx.createLinearGradient(m.x, m.y, tx, ty);
      g.addColorStop(0, `rgba(255,255,255,${al})`);
      g.addColorStop(0.35, `rgba(190,205,255,${al * 0.5})`);
      g.addColorStop(1, "rgba(190,205,255,0)");
      ctx.strokeStyle = g;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(m.x, m.y);
      ctx.lineTo(tx, ty);
      ctx.stroke();
      ctx.globalAlpha = al * 0.22;
      ctx.lineWidth = 4;
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  return {
    resize,
    start() { t0 = performance.now(); last = t0; raf = requestAnimationFrame(frame); },
    stop() { cancelAnimationFrame(raf); },
  };
}

/* ---------------------------------------------------------------- *
 *  SUNFLOWER FIELD — generated SVG, grown by CSS transitions
 * ---------------------------------------------------------------- */

/* soft-tipped petal, base at origin, pointing up */
const petalPath = (L) => {
  const w = L * 0.32;
  return `M0 0 C ${w} ${-L * 0.22} ${w * 0.95} ${-L * 0.6} ${w * 0.3} ${-L * 0.9} Q 0 ${-L * 1.04} ${-w * 0.3} ${-L * 0.9} C ${-w * 0.95} ${-L * 0.6} ${-w} ${-L * 0.22} 0 0 Z`;
};
const leafPath = (L) => {
  const w = L * 0.34;
  return `M0 0 C ${L * 0.28} ${-w} ${L * 0.72} ${-w * 0.85} ${L} ${-L * 0.06} C ${L * 0.72} ${w * 0.6} ${L * 0.28} ${w * 0.55} 0 0 Z`;
};

const DEFS = `
<defs>
  <linearGradient id="s1gStem" x1="0" y1="1" x2="0" y2="0">
    <stop offset="0" stop-color="#122017"/><stop offset="1" stop-color="#35523a"/>
  </linearGradient>
  <linearGradient id="s1gLeaf" x1="0" y1="0" x2="1" y2="0">
    <stop offset="0" stop-color="#182b1e"/><stop offset="1" stop-color="#35543e"/>
  </linearGradient>
  <linearGradient id="s1gPetalF" x1="0" y1="1" x2="0" y2="0">
    <stop offset="0" stop-color="#8a5c1a"/><stop offset="0.55" stop-color="#c9973c"/><stop offset="1" stop-color="#e3bd66"/>
  </linearGradient>
  <linearGradient id="s1gPetalF2" x1="0" y1="1" x2="0" y2="0">
    <stop offset="0" stop-color="#8a5a20"/><stop offset="0.55" stop-color="#c08a3a"/><stop offset="1" stop-color="#dcae62"/>
  </linearGradient>
  <linearGradient id="s1gPetalB" x1="0" y1="1" x2="0" y2="0">
    <stop offset="0" stop-color="#4c3210"/><stop offset="1" stop-color="#96702a"/>
  </linearGradient>
  <radialGradient id="s1gDisc" cx="0.5" cy="0.45" r="0.7">
    <stop offset="0" stop-color="#2a1a0c"/><stop offset="0.7" stop-color="#46301a"/><stop offset="1" stop-color="#5d4020"/>
  </radialGradient>
  <radialGradient id="s1gGlow">
    <stop offset="0" stop-color="rgba(236,197,108,0.10)"/>
    <stop offset="0.55" stop-color="rgba(236,197,108,0.035)"/>
    <stop offset="1" stop-color="rgba(236,197,108,0)"/>
  </radialGradient>
  <pattern id="s1pSeeds" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(24)">
    <circle cx="1.6" cy="2.1" r="0.9" fill="#1a0f06" opacity="0.7"/>
    <circle cx="4.7" cy="1.2" r="0.7" fill="#6b4a24" opacity="0.4"/>
    <circle cx="3.4" cy="4.8" r="0.8" fill="#241608" opacity="0.6"/>
    <circle cx="6.1" cy="5.6" r="0.65" fill="#7a5a2e" opacity="0.35"/>
  </pattern>
</defs>`;

function flowerMarkup(x, H, o) {
  const stemH = H * o.stemF;
  const headR = clamp(stemH * R(0.18, 0.24), 12, o.maxHead || 54);
  const lean = R(-16, 16);
  const tilt = R(-9, 9) - lean * 0.25;
  const sw = clamp(headR * 0.16, 2.4, 5.5);

  const c1x = R(-5, 5), c2x = R(-9, 9) + lean * 0.4;
  const stem = `<path class="stem" style="--sd:${o.sd}s" d="M0 0 C ${c1x} ${-stemH * 0.3} ${c2x} ${-stemH * 0.66} ${lean} ${-stemH}"
      fill="none" stroke="url(#s1gStem)" stroke-width="${sw}" stroke-linecap="round" pathLength="1"/>`;

  /* two leaves at different heights, opposite sides, each with a vein */
  let leaves = "";
  [0.42, 0.62].forEach((t, k) => {
    const side = k === 0 ? 1 : -1;
    const ax = lean * t + R(-2, 2);
    const ay = -stemH * t;
    const L = stemH * R(0.22, 0.3);
    const ld = (o.sd + 1.6 + k * 0.5).toFixed(2);
    leaves += `<g transform="translate(${ax} ${ay}) rotate(${side * -16}) scale(${side} 1)">
        <g class="leaf" style="--ld:${ld}s">
          <path d="${leafPath(L)}" fill="url(#s1gLeaf)"/>
          <path d="M${(L * 0.06).toFixed(1)} 0 C ${(L * 0.4).toFixed(1)} ${(-L * 0.02).toFixed(1)} ${(L * 0.7).toFixed(1)} ${(-L * 0.03).toFixed(1)} ${(L * 0.92).toFixed(1)} ${(-L * 0.05).toFixed(1)}"
            fill="none" stroke="#102015" stroke-width="1" opacity="0.5"/>
        </g></g>`;
  });

  /* head: glow, back ring, front ring, inner ring, seeded disc */
  const hd = (o.sd + 2.4 + R(0, 0.4)).toFixed(2);
  const pf = Math.random() < 0.5 ? "s1gPetalF" : "s1gPetalF2";
  const nB = 13, nF = 13, nI = 9;
  let petals = "";
  for (let i = 0; i < nB; i++) {
    const a = (i * 360) / nB + R(-4, 4);
    const j = R(0.93, 1.07);
    petals += `<g transform="rotate(${a.toFixed(1)}) scale(${j.toFixed(2)})"><path class="petal" style="--pd:${R(0, 0.5).toFixed(2)}s" d="${petalPath(headR * 1.22)}" fill="url(#s1gPetalB)"/></g>`;
  }
  for (let i = 0; i < nF; i++) {
    const a = (i * 360) / nF + 360 / (nF * 2) + R(-4, 4);
    const j = R(0.93, 1.07);
    petals += `<g transform="rotate(${a.toFixed(1)}) scale(${j.toFixed(2)})"><path class="petal" style="--pd:${(0.35 + R(0, 0.5)).toFixed(2)}s" d="${petalPath(headR * 1.05)}" fill="url(#${pf})"/></g>`;
  }
  for (let i = 0; i < nI; i++) {
    const a = (i * 360) / nI + R(-6, 6);
    const j = R(0.9, 1.1);
    petals += `<g transform="rotate(${a.toFixed(1)}) scale(${j.toFixed(2)})"><path class="petal" style="--pd:${(0.7 + R(0, 0.4)).toFixed(2)}s" d="${petalPath(headR * 0.78)}" fill="url(#${pf})"/></g>`;
  }
  const head = `
    <g transform="translate(${lean} ${-stemH}) rotate(${tilt.toFixed(1)})">
      <g class="head" style="--hd:${hd}s">
        <circle r="${(headR * 2.1).toFixed(1)}" fill="url(#s1gGlow)"/>
        ${petals}
        <circle r="${(headR * 0.5).toFixed(1)}" fill="url(#s1gDisc)"/>
        <circle r="${(headR * 0.46).toFixed(1)}" fill="url(#s1pSeeds)"/>
        <circle r="${(headR * 0.42).toFixed(1)}" fill="none" stroke="#1c1108" stroke-opacity="0.3"/>
        <circle r="${(headR * 0.3).toFixed(1)}" fill="none" stroke="#1c1108" stroke-opacity="0.3"/>
        <circle r="${(headR * 0.5).toFixed(1)}" fill="none" stroke="#8a6428" stroke-opacity="0.35"/>
      </g>
    </g>`;

  return `
  <g class="sway ${o.far ? "far" : ""}" style="--sw:${R(7.5, 11).toFixed(1)}s; --swd:${(-R(0, 9)).toFixed(1)}s; --sa:${R(1, 2).toFixed(1)}deg">
    <g transform="translate(${x.toFixed(1)} ${(H + 6).toFixed(1)})">
      ${stem}${leaves}${head}
    </g>
  </g>`;
}

function fieldSVG(w, h) {
  const n = clamp(Math.round(w / 105), 7, 15);
  const maxHead = w < 520 ? 42 : 54;
  const m = w * 0.04;
  const xs = Array.from({ length: n }, (_, i) => m + (i * (w - 2 * m)) / (n - 1) + R(-w * 0.02, w * 0.02));

  let far = "", near = "";
  xs.forEach((x, i) => {
    /* bloom travels across the frame like light arriving */
    const sd = +((i / (n - 1)) * 2.4 + R(0, 0.35)).toFixed(2);
    if (i % 2 === 1) far += flowerMarkup(x, h, { stemF: R(0.42, 0.58), sd: +sd, far: true, maxHead });
    else near += flowerMarkup(x, h, { stemF: R(0.62, 0.92), sd: +sd, far: false, maxHead });
  });
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMax meet" aria-hidden="true">${DEFS}${far}${near}</svg>`;
}

/* ---------------------------------------------------------------- *
 *  MOUNT
 * ---------------------------------------------------------------- */

function mount(root) {
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const el = document.createElement("div");
  el.className = "s1";
  el.innerHTML = `
    <canvas class="s1-sky"></canvas>
    <div class="s1-moon">
      <div class="s1-moon-glow"></div>
      <div class="s1-moon-stack">
        <img class="s1-moon-img" src="assets/moon.webp" alt="" draggable="false"/>
      </div>
    </div>
    <div class="s1-field"></div>
    <div class="s1-mist"></div>`;
  root.appendChild(el);

  const canvas = el.querySelector(".s1-sky");
  const fieldEl = el.querySelector(".s1-field");
  const sky = createSky(canvas, reduced);

  const buildField = (instant) => {
    const w = fieldEl.clientWidth, h = fieldEl.clientHeight;
    if (!w || !h) return;
    fieldEl.innerHTML = fieldSVG(Math.round(w), Math.round(h));
    if (instant) {
      el.classList.add("no-anim");
      requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove("no-anim")));
    }
  };

  sky.resize();
  sky.start();
  buildField(false);

  /* timeline */
  const T = [];
  const at = (ms, fn) => T.push(setTimeout(fn, ms));
  at(1200, () => el.classList.add("sky-in"));
  at(3400, () => el.classList.add("moon-in"));
  at(4600, () => el.classList.add("grow"));
  at(6000, () => el.classList.add("bloom"));

  const onResize = () => {
    sky.resize();
    buildField(true);
  };
  window.addEventListener("resize", onResize);

  return () => {
    T.forEach(clearTimeout);
    sky.stop();
    window.removeEventListener("resize", onResize);
    el.remove();
  };
}

registerScene({
  id: "scene-1",
  title: "Galaxy · meteor shower · sunflowers · moon",
  css: "css/scene-1.css",
  mount,
});
