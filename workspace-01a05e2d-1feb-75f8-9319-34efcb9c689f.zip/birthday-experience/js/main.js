/**
 * Entry point.
 *
 * Loads every scene module that exists, then mounts one for review:
 *   ?scene=N  → previews that exact scene
 *   (default) → previews the most recently built scene
 *
 * Scenes never know about each other. The continuous film is
 * assembled only after every scene is approved.
 */

import { listScenes, getScene } from "./registry.js";

const SCENE_MODULES = [
  "./scenes/scene-1.js",
  "./scenes/scene-2.js",
  "./scenes/scene-3.js",
  "./scenes/scene-4.js",
  "./scenes/scene-5.js",
  "./scenes/scene-6.js",
  "./scenes/scene-7.js",
  "./scenes/scene-8.js",
];

async function loadScenes() {
  for (const path of SCENE_MODULES) {
    try {
      await import(path);
    } catch {
      /* scene not built yet */
    }
  }
}

let activeCleanup = null;

function mountForReview() {
  const wanted = new URLSearchParams(location.search).get("scene");
  const built = listScenes();
  if (!built.length) {
    console.info("[film] stage ready — no scenes built yet");
    return;
  }
  const scene = (wanted && getScene(`scene-${wanted}`)) || built[built.length - 1];

  const mountEl = document.getElementById("stage-mount");
  mountEl.innerHTML = "";
  if (activeCleanup) {
    activeCleanup();
    activeCleanup = null;
  }

  activeCleanup = scene.mount(mountEl);
  console.info(`[film] reviewing → ${scene.id} (${scene.title})`);
}

async function boot() {
  await loadScenes();
  mountForReview();
}

boot();
