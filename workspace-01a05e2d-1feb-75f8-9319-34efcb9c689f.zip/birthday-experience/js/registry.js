/**
 * Scene registry.
 *
 * Every scene lives in its own file under js/scenes/ and calls
 * `registerScene({ id, title, css, mount })`. Nothing else in the
 * project needs to change when a new scene is added — this keeps
 * the one-codebase rule intact across all eight scenes.
 *
 * contract:
 *   css    → optional stylesheet path, injected once when registered
 *   mount  → (rootEl) => cleanupFn
 *            the scene builds its DOM inside rootEl and returns a
 *            function that tears everything down (timers, rAF,
 *            listeners, DOM) so scenes can be re-run cleanly.
 */

const scenes = [];
const loadedCss = new Set();

export function registerScene(scene) {
  if (!scene || !scene.id || typeof scene.mount !== "function") {
    console.warn("[registry] scene ignored — needs id + mount()");
    return;
  }
  if (scene.css && !loadedCss.has(scene.css)) {
    loadedCss.add(scene.css);
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = scene.css;
    document.head.appendChild(link);
  }
  scenes.push(scene);
  console.info(`[registry] scene available → ${scene.id}`);
}

export function getScene(id) {
  return scenes.find((s) => s.id === id) || null;
}

export function listScenes() {
  return scenes.slice();
}
