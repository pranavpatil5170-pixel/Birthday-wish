# A Birthday Film — interactive webpage

Built one scene at a time. Each scene is its own module and is never
rewritten once approved.

## Structure

```
birthday-experience/
├── index.html            stage + typography
├── css/base.css          reset, type scale, opening palette
├── js/
│   ├── config.js         ← ALL personal content lives here
│   ├── registry.js       scene registry (no edits needed when adding scenes)
│   ├── main.js           entry point, imports scenes in film order
│   └── scenes/           one file per scene
└── assets/               photos, music (add when provided)
```

## Production log

Scenes are locked once approved. Locked scenes are never rebuilt or
redesigned; later scenes are added on top.

- **Scene 1 — LOCKED 2026-09-01.**
  Black opening → sky + meteor shower (1.2s) → smaller moon, top-middle
  (3.4s, `min(44vmin, 250px)`, top `4vh`) → sunflowers grow stem-to-bloom
  in a left→right wave (grow 4.6s / bloom 6.0s), 7–13 flowers by width,
  far/near depth, ground mist, no text. Files: `js/scenes/scene-1.js`,
  `css/scene-1.css`. Do not modify without an explicit request.

## Film order

1. Galaxy + grey moon + opening line
2. Dense pink tulip garden, blooming
3. Birthday quote in the garden
4. Photographs + personal message
5. Cake + lily + single candle
6. Make a wish → 5 4 3 2 1 → blowout
7. Happy Birthday reveal
8. Personal message, moonlit ending

## Adding a scene

Create `js/scenes/scene-N.js`, and inside it call
`registerScene({ id, title, mount })`. `main.js` already imports the path.
Nothing from earlier scenes is touched.

## Palette

| Act | Colors |
| --- | --- |
| Opening | midnight blue · black · muted violet · silver moonlight |
| Garden | blush pink · pastel pink · peach · cream |
| Cake | ivory · warm gold · subtle blush |
| Wish | deep blue/black · warm gold |
| Ending | moonlit blue · silver · soft pink |

## Type

`Italiana` — single important lines.
`Cormorant Garamond` — everything else, light and italic where appropriate.
